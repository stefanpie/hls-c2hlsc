#pragma once

#include <stdio.h>

// C program to implement Quick Sort Algorithms
void quickSort(int arr[], int low, int high);